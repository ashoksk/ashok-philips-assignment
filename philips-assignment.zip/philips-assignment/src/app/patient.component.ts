import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { HttpErrorResponse } from '@angular/common/http';
import { Router } from "@angular/router";
import { FilterPipe  } from './services/search-service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-root',
  templateUrl: './patient.component.html',
  styleUrls: ['./css/patient.component.css']
})
export class PatientComponent {

  public showTable: boolean = null;
  public showForm: boolean = null;
  public saveBtn: boolean = null;
  public updateBtn: boolean = null;

  public searchString: string;

  patientForm: FormGroup;
  
  constructor (private httpService: HttpClient, private router: Router, private formBuilder: FormBuilder) {
   }

  patientlists: string [];
  newid: number;

  todaydate:Date;

  ngOnInit () {

    this.patientForm = this.formBuilder.group({
    });

    this.showTable = true;
    this.showForm = false;

    this.todaydate = new Date();

    this.httpService.get('http://localhost:4000/patients').subscribe(
      data => {
        this.patientlists = data as string [];	 // FILL THE ARRAY WITH DATA.
        this.newid = this.patientlists.length + 1;
       // console.log(this.newid);
      },
      (err: HttpErrorResponse) => {
        console.log (err.message);
      }
    );
  }

  birthday: any;
  today: any;
  age: any;

  onDobChange (value) {
   console.log(value);

  this.birthday = new Date(value);
  this.today = new Date();
   this.age = ((this.today - this.birthday) / (31557600000));
   this.myobject.age =  Math.floor( this.age );
  }

  numberOnly(event): boolean {
    const charCode = (event.which) ? event.which : event.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
      return false;
    }
    return true;
  }

  myobject: any;

  currentid = '';

  error: string = '';

  addPatient() {

    this.error = '';

    this.myobject = {
    };

    this.showForm = true;
    this.showTable = false;
    this.saveBtn = true;
    this.updateBtn = false;
  }

  updateid: number;

  editPatient(val) {

    this.error = '';

    this.updateid = val;

    this.showForm = true;
    this.showTable = false;

    this.saveBtn = false;
    this.updateBtn = true;

    this.httpService.get('http://localhost:4000/patients/' + val).subscribe(
      data => {
        this.myobject = data;
      //  console.log(data);
      },
      (err: HttpErrorResponse) => {
        console.log (err.message);
      }
    );
  }

  DeleteData (value) {
    this.httpService.delete("http://localhost:4000/patients/" + value)
    .subscribe(
      //('deleted successfully');
      result => window.location.reload()   
  )
  }

  viewPage(val) {
    this.router.navigate(['/patient-detail/' + val]);
  }

  save() {

    if (this.myobject.name == undefined) {
      this.error = 'please enter name'; 

    } else if (this.myobject.dob == undefined) {
      this.error = 'please select date of birth'; 

    } else if (this.myobject.age == undefined) {
      this.error = 'please enter age'; 

    } else if (this.myobject.phone == undefined || this.myobject.phone.length != 10) {
      this.error = 'please enter valid phone no'; 

    } else if (this.myobject.visitdate == undefined) {
      this.error = 'please select visit date'; 
    } else {

    this.httpService.post("http://localhost:4000/patients", this.myobject)
     .subscribe(resp => {
      // console.log(resp);
       window.location.reload() 
       this.showForm = false;
       this.showTable = true; 
     });
    }
  }

  update() {
    this.httpService.put("http://localhost:4000/patients/" + this.updateid, this.myobject)
     .subscribe(resp => {
      window.location.reload()  
      this.showForm = false;
      this.showTable = true;
     });
  }

  delete (value) {
    this.httpService.delete("http://localhost:4000/patients/" + value)
    .subscribe(
      result => window.location.reload()   
  )
  alert('deleted successfully');
  }

  cancel() {
    this.showForm = false;
    this.showTable = true;
  }

  logout() {
    this.router.navigate(['/']);
  }
}
