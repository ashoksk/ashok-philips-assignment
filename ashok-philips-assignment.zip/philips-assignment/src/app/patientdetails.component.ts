import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { HttpErrorResponse } from '@angular/common/http';
import { Router } from "@angular/router";
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-root',
  templateUrl: './patientdetails.component.html',
  styleUrls: ['./css/patient.component.css']
})
export class PatientDetailsComponent {

  constructor (private httpService: HttpClient, private router: Router, private route: ActivatedRoute) { }

  myobject = {};

  visitobject: any;

  private sub: any;
  id: number;

  public showTable: boolean = null;
  public showForm: boolean = null;
  public saveBtn: boolean = null;
  public updateBtn: boolean = null;

  patientvisits: string [];
  allpatientvisits: string [];
  newid: number;

  todaydate:Date;

  ngOnInit () {

    this.todaydate = new Date();

    this.showTable = true;
    this.showForm = false;

    this.sub = this.route.params.
    subscribe(
      params => this.id = +params['id']
    )

   // console.log(this.id);

    this.httpService.get('http://localhost:4000/patients/' + this.id).subscribe(
      data => {
        this.myobject = data;
       // console.log(data);
      },
      (err: HttpErrorResponse) => {
        console.log (err.message);
      }
    );

    this.httpService.get('http://localhost:4000/visits?patientid=' + this.id).subscribe(
      data => {
       // console.log(data);
        this.patientvisits = data as string [];
      },
      (err: HttpErrorResponse) => {
        console.log (err.message);
      }
    );

    this.httpService.get('http://localhost:4000/visits').subscribe(
      dat => {
        this.allpatientvisits = dat as string [];
        this.newid = this.allpatientvisits.length + 1;
      },
      (err: HttpErrorResponse) => {
        console.log (err.message);
      }
    );

  }
  
  addVisit() {
    this.showForm = true;
    this.showTable = false;
    this.saveBtn = true;
    this.updateBtn = false;

    this.visitobject = {
      patientid: 1
    };
  }

  cancel() {
    this.router.navigate(['/patient-list']);
  }

  cancelVisit() {
    this.showForm = false;
    this.showTable = true;
  }

  saveVisit() {

    this.visitobject.patientid = this.id;

    this.httpService.post("http://localhost:4000/visits/", this.visitobject)
     .subscribe(resp => {
       console.log(resp);
       this.showForm = false;
       this.showTable = true;
       window.location.reload() 
     });
  }

  updateid: number;

  editVisit(val) {

    this.updateid = val;

    this.showForm = true;
    this.showTable = false;

    this.saveBtn = false;
    this.updateBtn = true;

    this.httpService.get('http://localhost:4000/visits/' + val).subscribe(
      data => {
        this.visitobject = data;
        console.log(data);
      },
      (err: HttpErrorResponse) => {
        console.log (err.message);
      }
    );
  }

  updateVisit() {
    this.httpService.put("http://localhost:4000/visits/" + this.updateid, this.visitobject)
     .subscribe(resp => {
      window.location.reload()  
      this.showForm = false;
      this.showTable = true;
     });
  }

}
