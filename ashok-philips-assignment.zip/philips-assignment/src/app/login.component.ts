import { Component } from '@angular/core';
import { FormControl } from '@angular/forms';
import { Router } from "@angular/router";

@Component({
  selector: 'app-root',
  templateUrl: './login.component.html'
})
export class LoginComponent {

  constructor(private router: Router) {}

  obj = {
    username: '',
    password: ''
  };

  error: string = '';

  submit(obj) {
    console.log(obj);
    if (obj.username == '') {
      this.error = 'invalid username or password'; 
    } else if (obj.password == '') {
      this.error = 'invalid username or password'; 
    } else {
      this.error = '';
      console.log("Form Submitted!");
      this.router.navigate(['/patient-list']);
    }
     
  }
}
